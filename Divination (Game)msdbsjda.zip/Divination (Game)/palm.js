var test = getOption();
var output = "";
var output = "";

function getOption(){
	var selected = new Array();
	selected[0] = ""+document.querySelector('#begins').value; //inspiration from dropdown and chatgpt
	selected[1] = ""+document.querySelector('#appears1').value;
	selected[2] = ""+document.querySelector('#appears2').value;
	selected[3] = ""+document.querySelector('#appears3').value;
	selected[4] = ""+document.querySelector('#appears4').value;
	
	output = selected[0]+"<br>";
	for(let i=1; i<selected.length; i++){
		output += selected[i]+"<br>";
		//maybe put a function here, that spits back the interpretation at that index
	}
	
	return output;
}

function palmset(){
	test = getOption();
	localStorage.setItem("myValue", test);
}

function palmdisplay(){
	test = localStorage.getItem("myValue");
	document.getElementById("result").innerHTML = test;
}

function palmFate(nextPage){
	palmset();
	window.location.href = nextPage;
	location.replace(nextPage);
}

/*
var test = get();
//test = localStorage.getItem("myValue");


function get(){
	begins = document.querySelector('#begins');
	selectedOption = begins.value;
	
      //  selectElement = document.querySelector('#select1');
      //  output = selectElement.value;
        //document.querySelector('.output').textContent = output;
    
	return selectedOption+"";
}


function palmresult(){
	document.getElementById("result").innerHTML = test;
}


function palmFate(nextPage){
	//localStorage.setItem("myValue", test);
	window.location.href = nextPage;
	location.replace(nextPage);
}


/*
function palmReading() {
	let fatecounter = 0;
	let birthmonth = document.getElementById("month").value;
	
	
	
	//idea: use a loop to add up all the chosen values, put them in one string, and then return that big string;
	//idea2: use the fatecounter to have a loop add up the different values.
}

function getOption(){
	selectElement = document.querySelector('#appears1');
	output = selectElement.value;
	document.querySelector('.output').textContent = output;
	

}*/