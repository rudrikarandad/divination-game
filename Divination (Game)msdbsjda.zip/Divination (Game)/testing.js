var cards = new Array();
cards[0] = "tarot1";
cards[1] = "tarot2";
cards[2] = "tarot3";
cards[3] = "tarot4";
cards[4] = "tarot5";
cards[5] = "tarot6";
cards[6] = "tarot7";
cards[7] = "tarot8";
cards[8] = "tarot9";
cards[9] = "tarot10";
cards[10] = "tarot11";
cards[11] = "tarot12";
cards[12] = "tarot13";

function randomize(){
	let thisTarot = Math.floor(Math.random()*cards.length);
	output = cards[thisTarot];
	
	return output;
}

function display(){
	
	let x = "tarotimages/"+randomize();
	x = localStorage.getItem("myValue");
	document.getElementById("result2").innerHTML = x; //TBD. Just for checking if randomize worked.
	document.getElementById("result").src = x;

	// inspiration for .src from this: https://stackoverflow.com/questions/767143/variable-for-img-src
	
	document.getElementById("tarotButton1").onclick = null;
	document.getElementById("tarotButton2").onclick = null;
	document.getElementById("tarotButton3").onclick = null;
	document.getElementById("tarotButton4").onclick = null;
	document.getElementById("tarotButton5").onclick = null;
	document.getElementById("tarotButton6").onclick = null;

	/*code for button only being pressed once:
		https://stackoverflow.com/questions/32469366/javascript-button-pressed-only-once>
		It was used to get the ".onclick=null" parts of the code, to prevent display from being run again.
	*/	
}

function t1(){
	document.getElementById("tarot1").id = "result";
	display();
	
	/*The .id came from myself figuring out that if .src changed the src then .id could change the id
		Therefore I thought I would put different if statements to make a certain one 
		the one that would change images depending on which one was pressed. */
}
function t2(){
	document.getElementById("tarot2").id = "result";
	display();
}
function t3(){
	document.getElementById("tarot3").id = "result";
	display();
}
function t4(){
	document.getElementById("tarot4").id = "result";
	display();
}
function t5(){
	document.getElementById("tarot5").id = "result";
	display();
}
function t6(){
	document.getElementById("tarot6").id = "result";
	display();
}


//Can look at localstorage later to get inspiration on how to save certain values over multiple pages

var aValue = 0;

aValue = parseInt(localStorage.getItem("myValue"));
showA();

function showA()
{
	document.getElementById("aVal").innerHTML = "A = " + aValue;
}

function reset()
{
	aValue = 0;
	showA();
}

function addToValue(number)
{
	aValue += number;
	showA();
}

function goToNextPage(nextPage)
{
	localStorage.setItem("myValue", aValue)
	window.location.href = nextPage;
	location.replace(nextPage);
}
*/