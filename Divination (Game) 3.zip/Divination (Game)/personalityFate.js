var advice = new Array();
	advice[0] = "a dubious friend may be an enemy in camouflage";
	advice[1] = "a golden egg of opportunity will fall into your lap soon";
	advice[2] = "a good time to finish up old tasks";
	advice[3] = "a light heart carries you through all the dark times";
	advice[4] = "a new perspective will come with the new year";
	advice[5] = "all the troubles you have will pass away very quickly";
	advice[6] = "an acquaintance of the past will affect you in the near future";
	advice[7] = "be careful or you could fall for some tricks today";
	advice[8] = "change is happening in your life, so go with the flow";
	advice[9] = "curiousity kills boredom yet nothing kills curiousity";
	advice[10] = "do not underestimate yourself";
	advice[11] = "don't let the past and useless detail choke your existence";
	advice[12] = "don't worry, prosperity will knock on your door soon";
	advice[13] = "follow the middle path, neither extreme will make you happy";
	advice[14] = "your kindness will lead you to success";
	advice[15] = "help! i'm being held prisoner in a chinese bakery!";
	advice[16] = "in order to take, one must first give";
	advice[17] = "review some old lessons, they may come in handy";
	advice[18] = "a mind, once stretched by a new idea, never regains its original dimensions";
	advice[19] = "now is a good time to buy a stock";
	advice[20] = "today is a good day to pursue your love interest";
	advice[21] = "observe first, then judge";
	advice[22] = "pick battles big enough to matter, small enough to win";
	advice[23] = "rest has a peaceful effect on your physical and emotional health";
	advice[24] = "self-knowledge and awareness is a lifelong process";
	advice[25] = "share your joys and sorrows with your family";
	advice[26] = "someone you cares about seeks reconciliation";
	advice[27] = "the only people who never fails are those who never try";
	advice[28] = "the philosophy of one century is the common sense of the next";
	advice[29] = "there is a time for caution, but not for fear";
	advice[30] = "you will be traveling and coming into a fortune";

//advice sourced from https://joshmadison.com/2008/04/20/fortune-cookie-fortunes/

function personalityAdvice()
{
	let output = "";
	let thisAdvice = Math.floor(Math.random()*advice.length);
	output += advice[thisAdvice] + "<br>";
	
	document.getElementById("advice").innerHTML = output;
	document.getElementById("personalityAdvice").onclick = null;

	//code for button only being pressed once: https://stackoverflow.com/questions/32469366/javascript-button-pressed-only-once
}

var fate = new Array();
	fate[0] = "romanticist, supportive, and communicative";
	fate[1] = "sensitive and thoughtful";
	fate[2] = "thick-skinned and intelligent";
	fate[3] = "content and rational";
	fate[4] = "prone to feeling inadequate, yet loveable";
	fate[5] = "self-doubting, loyal, and tireless";
	fate[6] = "loyal, willing, and idealistic";
	fate[7] = "level-headed and tactful";
	fate[8] = "good-mannered, sensible, and perceptive";
	fate[9] = "loving and faithful";
	fate[10] = "persistent and optimistic";
	fate[11] = "self-critical, versatile, and systematic";
	fate[12] = "gentle and understanding";
	fate[13] = "reliable, factual, and courageous";
	fate[14] = "easily bored and philosophical";
	fate[15] = "light-hearted, nurturing, steadfast";
	fate[16] = "willing, calm, and resilient";
	fate[17] = "people-oriented and approachable";
	fate[18] = "sentimental, tidy, and considerate";
	fate[19] = "stable, careful, and stoic";
	fate[20] = "competitive, self-confident, and fast-paced";

//character traits sourced from https://writingexercises.co.uk/random-character-traits-generator.php

function personalityFate()
{
	let result = "";
	let thisFate = Math.floor(Math.random()*fate.length);
	result += fate[thisFate] + "<br>";
	
	document.getElementById("fate").innerHTML = result;
}