var test = getOption();
var output = "";

function getOption(){
	var selected = new Array();
	selected[0] = ""+document.querySelector('#begins').value; //inspiration from dropdown and chatgpt
	selected[1] = ""+document.querySelector('#appears1').value;
	selected[2] = ""+document.querySelector('#appears2').value;
	selected[3] = ""+document.querySelector('#appears3').value;
	selected[4] = ""+document.querySelector('#appears4').value;
	
	//Assigning a value to each chosen subject.
	var a1 = new Array();
	a1[0] = "begins below the index finger:";
	a1[1] = "begins below the middle finger:";
	a1[2] = "begins in between the middle and ring fingers:";
	a1[3] = "begins by touching the life line:";
	a1[4] = "begins parallel and straight to the head line:";
	a1[5] = "appears straight and short:";
	a1[6] = "appears long and curvy:";
	a1[7] = "appears wavy:";
	a1[8] = "appears broken up:";
	a1[9] = "appears marked by lines/circles:";
	a1[10] = "appears curved and sloping down:";
	a1[11] = "appears seperated from the lifeline:";
	a1[12] = "appears wavy:";
	a1[13] = "appears short:";
	a1[14] = "appears broken up:";
	a1[15] = "appears curvy:";
	a1[16] = "appears long and deep:";
	a1[17] = "appears short and shallow:";
	a1[18] = "appears straight and close to the edge of the palm:";
	a1[19] = "appears broken up:";
	a1[20] = "N/A:";
	a1[21] = "appears deep:";
	a1[22] = "appears broken up:";
	a1[23] = "appears joined to the life line at the bottom:";
	a1[24] = "appears crossing the lifeline:";
	
	
	for(let i=1; i<6; i++) //goes into each selected[i] (the different questions)
	{
		for(let j = i*10; j<5+i*10; j++){ //in each selected[i] it adds a value to output based on which option was selected from the dropdown
			if(selected[i-1] == "a"+j && i==1){ //this for loop is to find the value selected from the dropdown, and then get an appriopriate string from the array based on that selected value
				output = a1[j-10]+"<br><br>";
			}
			else if(selected[i-1] == "a"+j && i>1){
				output += a1[j-(5+5*i)]+"<br><br>";
			}
		}
	}
	
	return output;
}

function palmset(){
	test = getOption();
	localStorage.setItem("myValue", test);
}

function palmdisplay(){
	test = localStorage.getItem("myValue");
	document.getElementById("result").innerHTML = test;
}

function palmFate(nextPage){
	palmset();
	window.location.href = nextPage;
	location.replace(nextPage);
}
