var x = 0;
x = localStorage.getItem('completed');

function nextPage(pageName){
	x++;
	localStorage.setItem('completed', x);
	if(x>=4){
		x=0;
		localStorage.setItem('completed', x);
		window.location.href = "finalPage.html";
	}
	else{
		window.location.href = pageName;
		location.replace(pageName);
	}
}