function zodiacSign() {
	let birthmonth = document.getElementById("month").value;
	let birthday = document.getElementById("day").value;
	let output = "unknown because a valid data value was not inputted";

  if ((birthmonth == 1 && birthday >= 20) || (birthmonth == 2 && birthday <= 18)) 
	{
    output = "Aquarius";
	}

  if ((birthmonth == 2 && birthday >= 19) || (birthmonth == 3 && birthday <= 20))
	{
    output = "Pisces";
	}
	
  if ((birthmonth == 3 && birthday >= 21) || (birthmonth == 4 && birthday <= 19)) 
	{
    output = "Aries";
    }

  if ((birthmonth == 4 && birthday >= 20) || (birthmonth == 5 && birthday <= 20)) 
	{
    output = "Taurus";
	}

  if ((birthmonth == 5 && birthday >= 21) || (birthmonth == 6 && birthday <= 20)) 
	{
    output = "Gemini";
	}

  if ((birthmonth == 6 && birthday >= 21) ||(birthmonth == 7 && birthday <= 22)) 
	{
    output = "Cancer";
	}
	
  if ((birthmonth == 7 && birthday >= 23) || (birthmonth == 8 && birthday <= 22)) 
	{
    output = "Leo";
	}
	
  if ((birthmonth == 8 && birthday >= 23) || (birthmonth == 9 && birthday <= 22)) 
	{
    output = "Virgo";
	}
	
  if ((birthmonth == 9 && birthday >= 23) || (birthmonth == 10 && birthday <= 22)) 
	{
    output = "Libra";
	}
	
  if ((birthmonth == 10 && birthday >= 23) || (birthmonth == 11 && birthday <= 21)) 
	{
    output = "Scorpio";
	}
	
  if ((birthmonth == 11 && birthday >= 22) ||	(birthmonth == 12 && birthday <= 21)) 
	{
    output = "Sagittarius";
    }

  if ((birthmonth == 12 && birthday >= 22) || (birthmonth == 1 && birthday <= 19)) 
	{
    output = "Capricorn";
	} 
  
	document.getElementById("result").innerHTML = output;
	localStorage.setItem("output", output);
}

function zodiacFate(zodiacFate){
	window.location.href = zodiacFate;
	location.replace(zodiacFate);
}

function displayZodiac(){
    let fate = localStorage.getItem("output");
	document.getElementById("result1").innerHTML = fate;
}
