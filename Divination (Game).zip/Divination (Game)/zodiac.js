function zodiacSign() {
	let birthmonth = document.getElementById("month").value;
	let birthday = document.getElementById("day").value;
	let output = "unknown because a valid data value was not inputted";
	let trait = "";
	let descr = "";
	let img = "";
	// descr is short for description

	if ((birthmonth == 1 && birthday >= 20) || (birthmonth == 2 && birthday <= 18)) 
	{
		output = "Aquarius";
		trait = "A deep-thinker with a humanitarian streak, an Aquarian has grand plans to change the world. Shame that they left the party early though because their reclusive nature makes it hard for them to establish bonds with those around them.";
		descr = "element: air, mode: fixed, ruler: Saturn (Kronos, God of Time, the greater malefic), duality: diurnal"	
		img = "images/aquarius";
	}
	else if ((birthmonth == 2 && birthday >= 19) || (birthmonth == 3 && birthday <= 20))
	{
		output = "Pisces";
		trait = "If you are looking to escape the mundane everyday grind, a Pisces’s imaginative mind can whisk you away into a realm of fantasy. Their kind, nurturing personality can prove to be a double-edged sword though, because their overtly sensitive heart is easily wounded, further compounded by a tendency to play the victim."
		descr = "element: water, mode: mutable, ruler: Jupiter (Zeus, the Greater Benefic), duality: nocturnal"
		img = "images/pisces";
	}
	else if ((birthmonth == 3 && birthday >= 21) || (birthmonth == 4 && birthday <= 19)) 
	{
		output = "Aries";
		trait = "There is nothing an Aries cannot achieve once they set their mind to it—no mountain is too high. However, you will also find them nursing a hidden imposter syndrome that can chip away at their confidence if allowed free rein."
		descr = "element: fire, mode: cardinal, ruler: Mars (Ares, God of War, the lesser malefic), duality: diurnal"
		img = "images/aries";
    }
	else if ((birthmonth == 4 && birthday >= 20) || (birthmonth == 5 && birthday <= 20)) 
	{
		output = "Taurus";
		trait = "Loyal to a fault, a Taurean is the most reliable person you can have in your corner when the chips are down. However, they have a stubborn streak a mile wide and can hold a grudge like no one else, so make sure you don’t cross them."
		descr = "element: earth, mode: fixed, ruler: Venus (Aphrodite, Goddess of Love, the lesser benefic), duality: nocturnal"
		img = "images/taurus";
	}
	else if ((birthmonth == 5 && birthday >= 21) || (birthmonth == 6 && birthday <= 20)) 
	{
		output = "Gemini";
		trait = "Throw a Gemini to the wolves, and they will come back leading the pack—the air element in this sign means that they can adapt easily to any situation. But their fuse runs short and once they run out of patience with someone, there is no wiggle room for second chances."
		descr = "element: air, mode: mutable, ruler: Mercury (Hermes, Messender of the Gods), duality: diurnal"
		img = "images/gemini";
	}
	else if ((birthmonth == 6 && birthday >= 21) ||(birthmonth == 7 && birthday <= 22)) 
	{
		output = "Cancer";
		trait = "Behind the brooding fortress that a Cancer has erected to protect themselves are abundant reserves of deep, undying love and loyalty. Pity that few will get to experience it because they aren’t the best at communicating what is in their hearts."
		descr = "element: water, mode: cardinal, ruler: the Moon (traditionally ruler of the body, emotions, family, and travel), duality: nocturnal"
		img = "images/cancer";
	}
	else if ((birthmonth == 7 && birthday >= 23) || (birthmonth == 8 && birthday <= 22)) 
	{
		output = "Leo";
		trait = "Born to be under the spotlight, there is nothing that this lion enjoys as much as being the cynosure of all eyes. However, this innate conviction that they are always in the right means that they can often run roughshod over others’ feelings and sentiments."
		descr = "element: fire, mode: fixed, ruler: the Sun (traditionally ruler of core characteristics), duality: diurnal"
		img = "images/leo";
	}
	else if ((birthmonth == 8 && birthday >= 23) || (birthmonth == 9 && birthday <= 22)) 
	{
		output = "Virgo";
		trait = "Meticulous, organised and diligent, if the world were to end tomorrow, you would want a Virgo to lead the march into the new dawn. However, that pesky niggle of self-doubt in their head means that they are often harsher on themselves than anybody else can be."
		descr = "element: earth, mode: mutable, ruler: Mercury (Hermes, Messenger of the Gods, ruler of the mind), duality: nocturnal"
		img = "images/virgo";
	}
	else if ((birthmonth == 9 && birthday >= 23) || (birthmonth == 10 && birthday <= 22)) 
	{
		output = "Libra";
		trait = "If you are need someone to lend a comforting shoulder during times of distress. a Libra will always be there for you. This empathetic side of theirs can sometimes get derailed by their inability to make up their mind, compounded by a fear of confrontations, which means that you never truly know which side they stand on."
		descr = "element: air, mode: cardinal, ruler: Venus (Aphrodite, Goddess of Love, the lesser benefic), duality: diurnal"
		img = "images/libra";
	}
	else if ((birthmonth == 10 && birthday >= 23) || (birthmonth == 11 && birthday <= 21)) 
	{
		output = "Scorpio";
		trait = "The fiery, intense personality of a Scorpio can make any time spent together a wild, dizzying ride. But while they will go the extra mile to take care of your emotional needs, they remain notoriously secretive about their own—good luck cracking open the spine of this closed book."
		descr = "element: water, mode: fixed, ruler: Mars (Ares, God of War, the lesser malefic), duality: nocturnal"
		img = "images/scorpio";
	}
	else if ((birthmonth == 11 && birthday >= 22) ||	(birthmonth == 12 && birthday <= 21)) 
	{
		output = "Sagittarius";
		trait = "There is no storyteller quite like a Sagittarius—they can have the entire room hanging on their every word. But while they can show you grand dreams, it can sometimes be hard to pin them down and make them deliver on their promises."
		descr = "element: fire, mode: mutable, ruler: Jupiter (Zeus, the Greater Benefic), duality: diurnal"
		img = "images/sagittarius";
    }
	else if ((birthmonth == 12 && birthday >= 22) || (birthmonth == 1 && birthday <= 19)) 
	{
		output = "Capricorn";
		trait = "Not everyone can conquer the world but if a Cap were to set out to do it, nothing would deter them until they had accomplished their goal. With a personality that is hardwired in practicality, they can often fail to appreciate nuance and are known to be unforgiving of others’ mistakes."
		descr = "element: earth, mode: cardinal, ruler: Saturn (Kronos, God of Time, greater malefic), duality: nocturnal"
		img = "images/capricorn";
	} 
  
	document.getElementById("result").innerHTML = output;
	localStorage.setItem("output", output);
	localStorage.setItem("trait", trait);
	localStorage.setItem("descr", descr);
	localStorage.setItem("img", img);
}

function zodiacFate(zodiacFate){
	window.location.href = zodiacFate;
	location.replace(zodiacFate);
}

function displayZodiac(){
    let fate = localStorage.getItem("output");
	let fatetrait = localStorage.getItem("trait");
	let fatedescr = localStorage.getItem("descr");
	let zodiacimg = localStorage.getItem("img")
	document.getElementById("result1").innerHTML = fate;
	document.getElementById("character").innerHTML = fatetrait;
	document.getElementById("aspects").innerHTML = fatedescr;
	document.getElementById("zodiacimage").src = zodiacimg;
}


	