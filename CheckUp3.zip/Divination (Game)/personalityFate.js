var fate = new Array();
fate[0] = "a dubious friend may be an enemy in camoflauge";
fate[1] = "a golden egg of opportunity will fall into your lap soon";
fate[2] = "a good time to finish up old tasks";
fate[3] = "a light heart carries you through all the dark times";
fate[4] = "a new perspective will come with the new year";
fate[5] = "all the troubles you have will pass away very quickly";
fate[6] = "an acquaintance of the past will affect you in the near future";
fate[7] = "be careful or you could fall for some tricks today";
fate[8] = "change is happening in your life, so go with the flow";
fate[9] = "curiousity kills boredom yet nothing kills curiousity";
fate[10] = "do not underestimate yourself";
fate[11] = "don't let the past and useless detail choke your existence";
fate[12] = "don't worry, prosperity will knock on your door soon";
fate[13] = "follow the middle path, neither extreme will make you happy";
fate[14] = "your kindness will lead you to success";
fate[15] = "help! i'm being held prisoner in a chinese bakery!";
fate[16] = "in order to take, one must first give";
fate[17] = "review some old lessons, they may come in handy";
fate[18] = "a mind, once stretched by a new idea, never regains its original dimensions";
fate[19] = "now is a good time to buy a stock";
fate[20] = "today is a good day to pursue your love interest";
fate[21] = "observe first, then judge";
fate[22] = "pick battles big enough to matter, small enough to win";
fate[23] = "rest has a peaceful effect on your physical and emotional health";
fate[24] = "self-knowledge and awareness is a lifelong process";
fate[25] = "share your joys and sorrows with your family";
fate[26] = "someone you cares about seeks reconciliation";
fate[27] = "the only people who never fails are those who never try";
fate[28] = "the philosophy of one century is the common sense of the next";
fate[29] = "there is a time for caution, but not for fear";
fate[30] = "you will be traveling and coming into a fortune";

function personalityFate()
{
	let output = "";
	let thisFate = Math.floor(Math.random()*fate.length);
	output += fate[thisFate] + "<br>";
	
	document.getElementById("result").innerHTML = output;
	document.getElementById("fateButton").onclick = null;
	
	//code for button only being pressed once: https://stackoverflow.com/questions/32469366/javascript-button-pressed-only-once
}


var advice = new Array();
advice[0] = "romanticist, supportive, and communicative";
advice[1] = "sensitive and thoughtful";
advice[2] = "thick-skinned and intelligent";
advice[3] = "content and rational";
advice[4] = "prone to feeling inadequate, yet loveable";
advice[5] = "self-doubting, loyal, and tireless";
advice[6] = "loyal, willing, and idealistic";
advice[7] = "level-headed and tactful";
advice[8] = "good-mannered, sensible, and perceptive";
advice[9] = "loving and faithful";
advice[10] = "persistent and optimistic";
advice[11] = "self-critical, versatile, and systematic";
advice[12] = "gentle and understanding";
advice[13] = "reliable, factual, and courageous";
advice[14] = "easily bored and philosophical";
advice[15] = "light-hearted, nurturing, steadfast";
advice[16] = "willing, calm, and resilient";
advice[17] = "people-oriented and approachable";
advice[18] = "sentimental, tidy, and considerate";
advice[19] = "stable, careful, and stoic";
advice[20] = "competitive, self-confident, and fast-paced";

function personalityAdvice()
{
	let result = "";
	let thisAdvice = Math.floor(Math.random()*advice.length);
	result += advice[thisAdvice] + "<br>";
	
	document.getElementById("advice").innerHTML = result;
	document.getElementById("adviceButton").onclick = null;
}