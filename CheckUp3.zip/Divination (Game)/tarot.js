var cards = new Array();
cards[0] = "tarotimages/tarot1";
cards[1] = "tarotimages/tarot2";
cards[2] = "tarotimages/tarot3";
cards[3] = "tarotimages/tarot4";
cards[4] = "tarotimages/tarot5";
cards[5] = "tarotimages/tarot6";
cards[6] = "tarotimages/tarot7";
cards[7] = "tarotimages/tarot8";
cards[8] = "tarotimages/tarot9";
cards[9] = "tarotimages/tarot10";
cards[10] = "tarotimages/tarot11";
cards[11] = "tarotimages/tarot12";
cards[12] = "tarotimages/tarot13";


var info = new Array(); //reminder to add citations for this and the images
info[0] = "Upright: beginnings, innocence, spontaneity, a free spirit"+
	"<br><br>Reversed: holding back, recklessness, risk-taking";
info[1] = "Upright: manifestation, resourcefulness, power, inspired action"+
	"<br><br>Reversed: manipulation; poor planning, untapped talents";
info[2] = "Upright: intuition, sacred knowledge, divine feminine, the subconscious mind"+
	"<br><br>Reversed: secrets, disconnected from intuition, withdrawal and silence";
info[3] = "Upright: spiritual wisdom, religious beliefs, conformity, tradition, institutions"+
	"<br><br>Reversed: personal beliefs, freedom, challenging the status quo";
info[4] = "Upright: love, harmony, relationships, values alignment, choices"+
	"<br><br>Reversed: self-love, disharmony, imbalance, misalignment of values";
info[5] = "Upright: control, willpower, success, action, determination"+
	"<br><br>Reversed: self-discipline, opposition, lack of direction";
info[6] = "Upright: good luck, karma, life cycles, destiny, a turning point"+
	"<br><br>Reversed: bad luck, resistance to change, breaking cycles";
info[7] = "Upright: sudden change, upheaval, chaos, revelation, awakening"+
	"<br><br>Reversed: personal transformation, fear of change, averting disaster";
info[8] = "Upright: endings, change, transformation, transition"+
	"<br><br>Reversed: Resistance to change, personal transformation, inner purging";
info[9] = "Upright: balance, moderation, patience, purpose"+
	"<br><br>Reversed: Imbalance, excess, self-healing, re-alignment";
info[10] = "Upright: shadow self, attachment, addiction, restriction, sexuality"+
	"<br><br>Reversed: releasing limiting beliefs, exploring dark thoughts, detachment";
info[11] = "Upright: completion, integration, accomplishment, travel"+
	"<br><br>Reversed: seeking personal closure, short-cuts, delays";
info[12] = "Upright: soul-searching, introspection, being alone, inner guidance"+
	"<br><br>Reversed: isolation, loneliness, withdrawal";

function randomize(){
	let thisTarot = Math.floor(Math.random()*cards.length);
	output = cards[thisTarot];
	
	return output;
}

var x = randomize();
x = localStorage.getItem("myValue");
/*reminder to fix the issue of initial picture not loading
and to make the submit button only pressable after picking a tarot
*/

function t1(){
	document.getElementById("tarot1").id = "result";
	display();
	
	/*The .id came from myself figuring out that if .src changed the src then .id could change the id
		Therefore I thought I would put different if statements to make a certain one 
		the one that would change images depending on which one was pressed. */
}
function t2(){
	document.getElementById("tarot2").id = "result";
	display();
}
function t3(){
	document.getElementById("tarot3").id = "result";
	display();
}
function t4(){
	document.getElementById("tarot4").id = "result";
	display();
}
function t5(){
	document.getElementById("tarot5").id = "result";
	display();
}
function t6(){
	document.getElementById("tarot6").id = "result";
	display();
}

function newTarot(){
	document.getElementById("result").src = "tarotback";
	x = randomize();
	display();
}

function display(){
	document.getElementById("result").src = x;
	// inspiration for .src from this: https://stackoverflow.com/questions/767143/variable-for-img-src
	
	let index = 0;
	for(let i=0; i<cards.length; i++){
		if(x==cards[i]){
			index=i;
		}
	}
	let tarotinfo = info[index];
	document.getElementById("check").innerHTML = tarotinfo;
	
	
	document.getElementById("tarotButton1").onclick = null;
	document.getElementById("tarotButton2").onclick = null;
	document.getElementById("tarotButton3").onclick = null;
	document.getElementById("tarotButton4").onclick = null;
	document.getElementById("tarotButton5").onclick = null;
	document.getElementById("tarotButton6").onclick = null;
	/*code for button only being pressed once:
		https://stackoverflow.com/questions/32469366/javascript-button-pressed-only-once>
		It was used to get the ".onclick=null" parts of the code, to prevent display from being run again.
	*/
}

function tarotFate(nextPage){
	localStorage.setItem("myValue", x);
	window.location.href = nextPage;
	location.replace(nextPage);
}