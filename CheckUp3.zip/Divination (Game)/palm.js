var appears1 = document.getElementById('appears1');

dropdown.addEventListener('change', function(){
	var selectedOption = dropdown.value;
	localStorage.setItem('selectedOption', selectedOption);
});
		
var storedOption = localStorage.getItem('selectedOption');

document.getElementById("result").innerHTML = storedOption;






function palmReading() {
	let fatecounter = 0;
	let birthmonth = document.getElementById("month").value;
	
	
	
	//idea: use a loop to add up all the chosen values, put them in one string, and then return that big string;
	//idea2: use the fatecounter to have a loop add up the different values.
}

function getOption(){
	selectElement = document.querySelector('#appears1');
	output = selectElement.value;
	document.querySelector('.output').textContent = output;
}