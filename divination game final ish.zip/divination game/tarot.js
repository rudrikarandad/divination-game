//2 arrays; cards is the tarot card image sources and info is the information about them
var cards = new Array();
cards[0] = "tarotimages/tarot1";
cards[1] = "tarotimages/tarot2";
cards[2] = "tarotimages/tarot3";
cards[3] = "tarotimages/tarot4";
cards[4] = "tarotimages/tarot5";
cards[5] = "tarotimages/tarot6";
cards[6] = "tarotimages/tarot7";
cards[7] = "tarotimages/tarot8";
cards[8] = "tarotimages/tarot9";
cards[9] = "tarotimages/tarot10";
cards[10] = "tarotimages/tarot11";
cards[11] = "tarotimages/tarot12";
cards[12] = "tarotimages/tarot13";

var info = new Array(); //reminder to add citations for this and the image sources
info[0] = "Upright: beginnings, innocence, spontaneity, a free spirit"+
	"<br><br>Reversed: holding back, recklessness, risk-taking";
info[1] = "Upright: manifestation, resourcefulness, power, inspired action"+
	"<br><br>Reversed: manipulation; poor planning, untapped talents";
info[2] = "Upright: intuition, sacred knowledge, divine feminine, the subconscious mind"+
	"<br><br>Reversed: secrets, disconnected from intuition, withdrawal and silence";
info[3] = "Upright: spiritual wisdom, religious beliefs, conformity, tradition, institutions"+
	"<br><br>Reversed: personal beliefs, freedom, challenging the status quo";
info[4] = "Upright: love, harmony, relationships, values alignment, choices"+
	"<br><br>Reversed: self-love, disharmony, imbalance, misalignment of values";
info[5] = "Upright: control, willpower, success, action, determination"+
	"<br><br>Reversed: self-discipline, opposition, lack of direction";
info[6] = "Upright: good luck, karma, life cycles, destiny, a turning point"+
	"<br><br>Reversed: bad luck, resistance to change, breaking cycles";
info[7] = "Upright: sudden change, upheaval, chaos, revelation, awakening"+
	"<br><br>Reversed: personal transformation, fear of change, averting disaster";
info[8] = "Upright: endings, change, transformation, transition"+
	"<br><br>Reversed: Resistance to change, personal transformation, inner purging";
info[9] = "Upright: balance, moderation, patience, purpose"+
	"<br><br>Reversed: Imbalance, excess, self-healing, re-alignment";
info[10] = "Upright: shadow self, attachment, addiction, restriction, sexuality"+
	"<br><br>Reversed: releasing limiting beliefs, exploring dark thoughts, detachment";
info[11] = "Upright: completion, integration, accomplishment, travel"+
	"<br><br>Reversed: seeking personal closure, short-cuts, delays";
info[12] = "Upright: soul-searching, introspection, being alone, inner guidance"+
	"<br><br>Reversed: isolation, loneliness, withdrawal";

////////////////////////////////////

/*two variables, both put into localStorage; 
x is to randomly get a tarot card img src from the card array
y uses a for loop to get the index position of where x is in the array.
This is the same position for the information, 
so it returns the information in the other array as a string using the found index.*/
var x = randomize();
var y = getindex();
x = localStorage.getItem("xValue");
y = localStorage.getItem("yValue");

function randomize(){
	let thisTarot = Math.floor(Math.random()*cards.length);
	output = cards[thisTarot];
	
	return output;
}
function getindex(){
    let index = 0;
	for(let i=0; i<cards.length; i++){
		if(x==cards[i]){
			index=i;
		}
	}
	let tarotinfo = info[index];
    return tarotinfo;
}


/*These functions are for the buttons. The main point of having multiple functions
is because passing in values into the parentheses when calling the functions in the HTML does not work. 
To change a specific id based on which button was pressed, different functions for each button needed to be made.
It also properly initializes the image that shows up after pressing the button*/
function t1(){
	document.getElementById("tarot1").id = "result";
	x = randomize();
    y = getindex();
	display();
	
	/*The .id came from myself figuring out that if .src changed the src then .id could change the id
		Therefore I thought I would put different if statements to make a certain one 
		the one that would change images depending on which one was pressed. */
}
function t2(){
	document.getElementById("tarot2").id = "result";
	x = randomize();
    y = getindex();
	display();
}
function t3(){
	document.getElementById("tarot3").id = "result";
	x = randomize();
    y = getindex();
	display();
}
function t4(){
	document.getElementById("tarot4").id = "result";
	x = randomize();
    y = getindex();
	display();
}
function t5(){
	document.getElementById("tarot5").id = "result";
	x = randomize();
    y = getindex();
	display();
}
function t6(){
	document.getElementById("tarot6").id = "result";
	x = randomize();
    y = getindex();
	display();
}

/*The first two functions display x and y respectively. 
The first also makes the other buttons stop being pressable after the first press.
The only way to get a different tarot reading is to press the button to get a new tarot.
That button goes to the function newTarot, which gets the x and y values again and displays a different tarot card (x).*/
function display(){
	document.getElementById("result").src = x;
	// inspiration for .src from this: https://stackoverflow.com/questions/767143/variable-for-img-src
    
	document.getElementById("tarotButton1").onclick = null;
	document.getElementById("tarotButton2").onclick = null;
	document.getElementById("tarotButton3").onclick = null;
	document.getElementById("tarotButton4").onclick = null;
	document.getElementById("tarotButton5").onclick = null;
	document.getElementById("tarotButton6").onclick = null;
	/*code for button only being pressed once:
		https://stackoverflow.com/questions/32469366/javascript-button-pressed-only-once>
		It was used to get the ".onclick=null" parts of the code, to prevent display from being run again.*/
}
function checky(){
    document.getElementById("check").innerHTML = y;
}
function newTarot(){
	document.getElementById("result").src = "tarotback";
	x = randomize();
    y = getindex();
	display();
}

//This is for localStorage and changes the page.
function tarotFate(nextPage){
	localStorage.setItem("xValue", x);
    localStorage.setItem("yValue", y);
	window.location.href = nextPage;
	location.replace(nextPage);
}