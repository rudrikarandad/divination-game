var test = getOption();
var output = "";

function getOption(){
	var selected = new Array();
	selected[0] = ""+document.querySelector('#begins').value; //inspiration from dropdown and chatgpt
	selected[1] = ""+document.querySelector('#appears1').value;
	selected[2] = ""+document.querySelector('#appears2').value;
	selected[3] = ""+document.querySelector('#appears3').value;
	selected[4] = ""+document.querySelector('#appears4').value;
	
	//Assigning a value to each chosen subject.
    //inspiration for these values comes from this website: https://www.wikihow.com/Read-Palms
	//and https://www.allure.com/story/palm-reading-guide-hand-lines
	var a1 = new Array();
	a1[0] = "begins below the index finger: content with love life";
	a1[1] = "begins below the middle finger: selfish when it comes to love";
	a1[2] = "begins in between the middle and ring fingers: falls in love easily";
	a1[3] = "begins by touching the life line: heart is broken easily";
	a1[4] = "begins parallel and straight to the head line: good handle on emotions";
	a1[5] = "appears straight and short: less interest in romance";
	a1[6] = "appears long and curvy: freely expresses emotions and feelings";
	a1[7] = "appears wavy: many relationships and lovers, absence of serious relationships";
	a1[8] = "appears broken up: emotional trauma";
	a1[9] = "appears marked by lines/circles: sadness or deppression";
	a1[10] = "appears curved and sloping down: creativity";
	a1[11] = "appears seperated from the lifeline: adventure, enthusiasm for lfie";
	a1[12] = "appears wavy: short attention span";
	a1[13] = "appears short: prefers physical acheviements over mental ones";
	a1[14] = "appears broken up: inconsistencies in thought";
	a1[15] = "appears curvy: plenty of energy";
	a1[16] = "appears long and deep: vitality";
	a1[17] = "appears short and shallow: manipulated by others";
	a1[18] = "appears straight and close to the edge of the palm: cautious when it comes to relationships";
	a1[19] = "appears broken up: sudden change in lifestyle";
	a1[20] = "N/A: not controlled by fate";
	a1[21] = "appears deep: strongly controlled by fate";
	a1[22] = "appears broken up: prone to many changes in life from external forces";
	a1[23] = "appears joined to the life line at the bottom: self-made individual; develops aspirations early on";
	a1[24] = "appears crossing the lifeline: support offered by family and friends";
	a1[25] = "Earth: solid values & practical; sometimes stubborn & materialistic";
	a1[26] = "Fire: spontaneous & extroverted; sometimes impulsive & insensitive";
	a1[27] = "Air: sociable & introspective; sometimes shallow & spiteful";
	a1[28] = "Water: creative & intuitive; sometimes emotional and inhibited";
	a1[29] = "Saturn: wisdom; responsibility; fortitude";
	a1[30] = "Jupiter: confidence; ambition; leadership";
	a1[31] = "Inner Mars: aggressive; physical strength";
	a1[32] = "Venus: passion; indulgence";
	a1[33] = "Plain of Mars: temperament; balance";
	a1[34] = "Luna: imagination; intuition; connection to spirituality";
	a1[35] = "Outer Mars: resilient; perserverant";
	a1[36] = "Mercury: communication; intelligence";
	a1[37] = "Apollo: optimism; vitality; potential for success";
	
	//goes into each selected[i] (the different questions)
	//in each selected[i] it adds a value to output based on which option was selected from the dropdown
	//this for loop is to find the value selected from the dropdown, and then get an appriopriate string from the array based on that selected value
	for(let i=1; i<6; i++) 
	{
		for(let j = i*10; j<5+i*10; j++){ 
			if(selected[i-1] == "a"+j && i==1){
				output = a1[j-10]+"<br><br>";
			}
			else if(selected[i-1] == "a"+j && i>1){
				output += a1[j-(5+5*i)]+"<br><br>";
			}
		}
	}
	
	//These two for loops are for getting the values of the radio buttons
    var shape = document.getElementsByName('q5');
	for(let i=1; i<shape.length+1; i++){
		if(shape[i-1].value == "q"+i && shape[i-1].checked){
			output += a1[i+24]+"<br><br>";
		}
	}
	var mounts = document.getElementsByName('q6');
	for(let i=5; i<mounts.length+5; i++){
		if(mounts[i-5].value == "q"+i && mounts[i-5].checked){
			output += a1[i+24]+"<br><br>";
		}
	}
	
	return output;
}

function palmset(){
	test = getOption();
	localStorage.setItem("myValue", test);
}

function palmdisplay(){
	test = localStorage.getItem("myValue");
	document.getElementById("result").innerHTML = test;
}

function palmFate(nextPage){
	palmset();
	window.location.href = nextPage;
	location.replace(nextPage);
}