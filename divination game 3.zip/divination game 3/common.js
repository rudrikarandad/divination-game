function completePage(pageName) {
	localStorage.setItem(pageName, 'completed');
	if(areAllPagesCompleted()) {
		window.location.href = "finalPage.html';
	}
}

function areAllPagesCompleted() {
	const pages = ['page1, 'page2', 'page3', 'page4'];
	return pages.every(page => localStorage.getItem(page) === 'completed');
}