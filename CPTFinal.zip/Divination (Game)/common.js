var value = 0;
value = localStorage.getItem('completed');

function nextPage(pageName){
	value++;
	localStorage.setItem('completed', value);
	if(value>=4){
		value=0;
		localStorage.setItem('completed', value);
		window.location.href = "finalPage.html";
	}
	else{
		window.location.href = pageName;
		location.replace(pageName);
	}
}