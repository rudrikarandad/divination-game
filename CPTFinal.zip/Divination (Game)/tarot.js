//2 arrays; cards is the tarot card image sources and info is the information about them
var cards = new Array();
	cards[0] = "tarotimages/tarot1";
	cards[1] = "tarotimages/tarot2";
	cards[2] = "tarotimages/tarot3";
	cards[3] = "tarotimages/tarot4";
	cards[4] = "tarotimages/tarot5";
	cards[5] = "tarotimages/tarot6";
	cards[6] = "tarotimages/tarot7";
	cards[7] = "tarotimages/tarot8";
	cards[8] = "tarotimages/tarot9";
	cards[9] = "tarotimages/tarot10";
	cards[10] = "tarotimages/tarot11";
	cards[11] = "tarotimages/tarot12";
	cards[12] = "tarotimages/tarot13";

var info = new Array(); 
	info[0] = "Represents: beginnings, innocence, spontaneity, a free spirit <br> <br> The Fool is a card of new beginnings, opportunity and potential. It encourages you to have an open, curious mind and a sense of excitement. Be ready to embrace the unknown, leaving behind any fear, worry or anxiety about what may or may not happen. This is about new experiences, personal growth, development, and adventure.";
	info[1] = "Represents: manifestation, resourcefulness, power, inspired action <br> <br> Now is the perfect time to move forward on an idea that you recently conceived. The seed of potential has sprouted, and you are being called to take action and bring your intention to fruition. The skills, knowledge and capabilities you have gathered along your life path have led you to where you are now, and whether or not you know it, you are ready to turn your ideas into reality.";
	info[2] = "Represents: intuition, sacred knowledge, divine feminine, the subconscious mind <br> <br> The High Priestess signifies spiritual enlightenment, inner illumination, divine knowledge and wisdom. She shows up in your Tarot readings when the veil between you and the underworld is thin, and you have the opportunity to access the knowledge deep within your soul. Now is the time to be still so you can tune in to your intuition.";
	info[3] = "Represents: spiritual wisdom, religious beliefs, conformity, tradition, institutions <br> <br> Work with a teacher, mentor, or guide to teach you about spiritual values and beliefs in a structured way.If you have already mastered a particular field of study, you may be taking on the role of teacher and mentor to others. In this position, you honour and acknowledge your responsibility to share your knowledge in a structured way, one that respects the age-old traditions.";
	info[4] = "Represents: love, harmony, relationships, values alignment, choices <br> <br> The Lovers card represents conscious connections and meaningful relationships. The arrival of this card in a Tarot reading shows that you have a beautiful, soul-honoring connection with a loved one. The Lovers is a card of open communication and raw honesty.";
	info[5] = "Represents: control, willpower, success, action, determination <br> <br> The Chariot is a card of willpower, determination, and strength. You have set your objectives and are now channeling your inner power with a fierce dedication to bring them to fruition. When you apply discipline, commitment and willpower to achieve your goals, you will succeed.";
	info[6] = "Represents: good luck, karma, life cycles, destiny, a turning point <br> <br> The Wheel of Fortune reminds you that the wheel is always turning and life is in a state of constant change. If you’re going through a difficult time rest assured that it will get better from here. Good luck and good fortune will make their return in time.";
	info[7] = "Represents: sudden change, upheaval, chaos, revelation, awakening <br> <br> Expect the unexpected – massive change, upheaval, destruction and chaos. Everything you thought to be true has turned on its head. You are now questioning what is real and what is not; what you can rely upon and what you cannot trust.";
	info[8] = "Represents: endings, change, transformation, transition <br> <br> The Death card symbolizes the end of a major phase or aspect of your life that you realize is no longer serving you, opening up the possibility of something far more valuable and essential. Death shows a time of significant transformation, change, and transition.";
	info[9] = "Represents: balance, moderation, patience, purpose <br> <br> Temperance is the card for bringing balance, patience and moderation into your life. You are being invited to stabilise your energy and to allow the life force to flow through you without force or resistance. It’s time to recover your flow and get your life back into order and balance.";
	info[10] = "Represents: shadow self, attachment, addiction, restriction, sexuality <br> <br> You may be at the effect of negative habits, dependencies, behaviors, thought patterns, relationships, and addictions. You have found yourself trapped between the short-term pleasure you receive and the longer-term pain you experience.";
	info[11] = "Represents: completion, integration, accomplishment, travel <br> <br> You are glowing with a sense of wholeness, achievement, fulfilment, and completion. A long-term project, period of study, relationship or career has come full circle, and you are now reveling in the sense of closure and accomplishment.";
	info[12] = "Represents: soul-searching, introspection, being alone, inner guidance <br> <br> The Hermit shows that you are taking a break from everyday life to draw your energy and attention inward and find the answers you seek, deep within your soul. Now is the perfect time to go on a weekend retreat or sacred pilgrimage, anything in which you can contemplate your motivations, personal values and principles, and get closer to your authentic self.";

//tarot card info sourced from https://biddytarot.com/tarot-card-meanings/major-arcana/

/*two variables, both put into localStorage; 
x is to randomly get a tarot card img src from the card array
y uses a for loop to get the index position of where x is in the array.
This is the same position for the information, 
so it returns the information in the other array as a string using the found index.*/

var x = randomize();
var y = getindex();
x = localStorage.getItem("xValue");
y = localStorage.getItem("yValue");

function randomize(){
	let thisTarot = Math.floor(Math.random()*cards.length);
	output = cards[thisTarot];
	
	return output;
}

function getindex(){
	let index = 0;
	for(let i=0; i<cards.length; i++){
		if(x==cards[i]){
			index=i;
		}
	}
	let tarotinfo = info[index];
	return tarotinfo;
}


/*These functions are for the buttons. The main point of having multiple functions
is because passing in values into the parentheses when calling the functions in the HTML does not work. 
To change a specific id based on which button was pressed, different functions for each button needed to be made.
It also properly initializes the image that shows up after pressing the button*/

function t1(){
	document.getElementById("tarot1").id = "result";
	x = randomize();
	y = getindex();
	display();
	
	/*The .id came from myself figuring out that if .src changed the src then .id could change the id
		Therefore I thought I would put different if statements to make a certain one 
		the one that would change images depending on which one was pressed. */
}
function t2(){
	document.getElementById("tarot2").id = "result";
	x = randomize();
	y = getindex();
	display();
}
function t3(){
	document.getElementById("tarot3").id = "result";
	x = randomize();
	y = getindex();
	display();
}
function t4(){
	document.getElementById("tarot4").id = "result";
	x = randomize();
	y = getindex();
	display();
}
function t5(){
	document.getElementById("tarot5").id = "result";
	x = randomize();
	y = getindex();
	display();
}
function t6(){
	document.getElementById("tarot6").id = "result";
	x = randomize();
	y = getindex();
	display();
}

/*The first two functions display x and y respectively. 
The first also makes the other buttons stop being pressable after the first press.
The only way to get a different tarot reading is to press the button to get a new tarot.
That button goes to the function newTarot, which gets the x and y values again and displays a different tarot card (x).*/

function display(){
	document.getElementById("result").src = x;
	// inspiration for .src from this: https://stackoverflow.com/questions/767143/variable-for-img-src
    
	document.getElementById("tarotButton1").onclick = null;
	document.getElementById("tarotButton2").onclick = null;
	document.getElementById("tarotButton3").onclick = null;
	document.getElementById("tarotButton4").onclick = null;
	document.getElementById("tarotButton5").onclick = null;
	document.getElementById("tarotButton6").onclick = null;
	/*code for button only being pressed once:
		https://stackoverflow.com/questions/32469366/javascript-button-pressed-only-once>
		It was used to get the ".onclick=null" parts of the code, to prevent display from being run again.*/
}

function checky(){
	document.getElementById("check").innerHTML = y;
}

function newTarot(){
	document.getElementById("result").src = "tarotback";
	x = randomize();
	y = getindex();
	display();
}

//This is for localStorage and changes the page.

function tarotFate(nextPage){
	localStorage.setItem("xValue", x);
	localStorage.setItem("yValue", y);
	window.location.href = nextPage;
	location.replace(nextPage);
}